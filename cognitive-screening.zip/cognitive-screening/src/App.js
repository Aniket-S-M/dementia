import React, { useState } from "react";
import axios from "axios";
import { v4 as uuidv4 } from "uuid";

function App() {
  const [age, setAge] = useState(68);
  const [gender, setGender] = useState("F");
  const [education, setEducation] = useState(17);

  // Scores
  const [scores, setScores] = useState({
    memory: 0,
    attention: 0,
    language: 0,
    executive: 0,
    visuospatial: 0,
    reaction: 0,
    mood: 0
  });

  // Example: Memory test
  const handleMemoryTest = () => {
    const correct = Math.floor(Math.random() * 10) + 5; // demo random score
    setScores(prev => ({ ...prev, memory: correct }));
  };

  // Example: Attention test
  const handleAttentionTest = () => {
    const score = Math.floor(Math.random() * 20) + 10;
    setScores(prev => ({ ...prev, attention: score }));
  };

  // Other tests simulated similarly
  const handleLanguageTest = () => setScores(prev => ({ ...prev, language: Math.floor(Math.random() * 20) + 10 }));
  const handleExecutiveTest = () => setScores(prev => ({ ...prev, executive: Math.floor(Math.random() * 20) + 10 }));
  const handleVisuospatialTest = () => setScores(prev => ({ ...prev, visuospatial: Math.floor(Math.random() * 20) + 10 }));
  const handleReactionTest = () => setScores(prev => ({ ...prev, reaction: Math.random() * 500 + 200 })); // ms
  const handleMoodTest = () => setScores(prev => ({ ...prev, mood: Math.floor(Math.random() * 10) + 1 }));

  const handleSubmit = async () => {
    const payload = {
      subject_id: uuidv4(),
      age,
      gender,
      education_years: education,
      memory_score: scores.memory,
      attention_score: scores.attention,
      language_score: scores.language,
      executive_score: scores.executive,
      visuospatial_score: scores.visuospatial,
      reaction_time_ms: scores.reaction,
      mood_score: scores.mood
    };

    try {
      const res = await axios.post("http://127.0.0.1:8000/submit_cognitive_test", payload);
      console.log("Server response:", res.data);
      alert("Test submitted! Check console for server response.");
    } catch (err) {
      console.error(err);
      alert("Error submitting test");
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Live Cognitive Screening</h1>
      <div>
        <label>Age: </label>
        <input type="number" value={age} onChange={e => setAge(e.target.value)} />
      </div>
      <div>
        <label>Gender: </label>
        <select value={gender} onChange={e => setGender(e.target.value)}>
          <option value="F">Female</option>
          <option value="M">Male</option>
        </select>
      </div>
      <div>
        <label>Education (years): </label>
        <input type="number" value={education} onChange={e => setEducation(e.target.value)} />
      </div>

      <h2>Tests</h2>
      <button onClick={handleMemoryTest}>Run Memory Test</button> Score: {scores.memory} <br />
      <button onClick={handleAttentionTest}>Run Attention Test</button> Score: {scores.attention} <br />
      <button onClick={handleLanguageTest}>Run Language Test</button> Score: {scores.language} <br />
      <button onClick={handleExecutiveTest}>Run Executive Test</button> Score: {scores.executive} <br />
      <button onClick={handleVisuospatialTest}>Run Visuospatial Test</button> Score: {scores.visuospatial} <br />
      <button onClick={handleReactionTest}>Run Reaction Test</button> Score: {scores.reaction.toFixed(2)} ms <br />
      <button onClick={handleMoodTest}>Run Mood Test</button> Score: {scores.mood} <br />

      <br />
      <button onClick={handleSubmit} style={{ backgroundColor: "green", color: "white", padding: 10 }}>
        Submit Test
      </button>
    </div>
  );
}

export default App;
